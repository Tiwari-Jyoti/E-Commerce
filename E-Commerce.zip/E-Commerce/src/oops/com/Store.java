package oops.com;

import java.util.Scanner;

public class Store {

	public static void main(String[] args) {
	System.out.println("Welcome to the ecommerce store");
	System.out.println("Which type of user are you 1. Customer 2. seller 3. Admin");
	Scanner sc = new Scanner(System.in);
	int Choice = sc.nextInt();
	String typeofuser;
    if(Choice==1) {
    	typeofuser = "Customer";
     Customer current = new Customer();
     System.out.println("what is your userId");
     current.setUserId(sc.nextLine());
     System.out.println("What is password");
     current.setUserId(sc.nextLine());
    if( current.verifyUser()==true) {
       System.out.println("User verified");
       while(true){
       System.out.println("Do you want to 1. view products 2. view cart 3. contact us 4. Exit");
       Choice=sc.nextInt();
       if(Choice==1) {
    	Catalogue catalogue = new Catalogue();
    	Product [] allProducts = catalogue.getListofAllProducts();
    	for(int i=0; i<allProducts.length; i++) {
    		System.out.println(allProducts[i].getProductId()+" "+allProducts[i].getProductName()+" "+allProducts[i].getCost());
    	}
    	System.out.println("Do you want to add any Product to the cart? Y/N");
    	String addTocart=sc.nextLine();
    	if(addTocart=="Y")
    	{
    		System.out.println("Input the Prduct id of the Product which you want to add to cart.");
    		String Product=sc.nextLine();
    		Product[]cartproducts= new Product[1] ;
    		for(int i=0; i<allProducts.length; i++) {
    			if((allProducts[i].getProductId().equals(Product)))
    				cartproducts[0]=allProducts[i];  	
    			
    		}
    		
    		cart Cart = new cart();
    		Cart.setCartId("1");
    		Cart.setListofProducts(cartproducts);
    		
    		current.setCart(Cart);
    	 	System.out.println("the Product is successfully added to the cart");
    	}
    	
       }
    	if(Choice==2) {
    		Product[] Cartproducts= current.getCart().getListofProducts();
    		System.out.println(current.getCart().getCartId());
    		for(int i=0; i<Cartproducts.length; i++) {
    			System.out.println(1);
    			System.out.println(Cartproducts[i].getProductId()+" "+Cartproducts[i].getProductName()+" "+Cartproducts[i].getCost());				  
    			
    		}
    		System.out.println("D you want to checkout? Y/N");
    		sc.nextLine();
    		String checkout=sc.nextLine();
    		if(checkout.equals("y"))
    			if(current.getCart().checkout())
    			System.out.println("your order is placed successfully");	
    	}
    	else if(Choice==3) {
    		System.out.println("to contact us. please email on store@ecommerce.com");
    	}
    	else if (Choice==4)
    		break;
    	else
    		System.out.println("Invalid choice, please try again");
    	}
       
    	
       }
    
    }
    else if(Choice==2)
		typeofuser = "Seller";
	else if(Choice==3)
		typeofuser = "Admin";
	else
		System.out.println("Invelid input Try again");
    
		
    }	
		
    }