package oops.com;


public class Category {
    private	String categoryName;
	private Category [] subategories;
	
	protected String getCategoryName() {
		return categoryName;
	}
	
	protected void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	protected Category[] getSubategories() {
		return subategories;
	}
	
	protected  void setSubategories(Category[] subategories) {
		this.subategories = subategories;
	}
	 
		
	

}
