package oops.com;


public abstract class User {
	String userId="";
	String passwrd="";
	String loginStatus="";
abstract Boolean verifyUser();
protected String getUserId() {
	return userId;
}
protected void setUserId(String userId) {
	this.userId = userId;
}
protected String getPasswrd() {
	return passwrd;
}
protected void setPasswrd(String passwrd) {
	this.passwrd = passwrd;
}
protected String getLoginStotus() {
	return loginStatus;
}

protected void setLoginStotus(String loginStatus) {
	this.loginStatus = loginStatus;
}  
	

}
   