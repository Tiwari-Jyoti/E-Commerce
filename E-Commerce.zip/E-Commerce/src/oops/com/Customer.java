package oops.com;

public class Customer extends User{
	 cart cart;
	 String productId;
	protected cart getCart() {
		return cart;
	}
	protected void setCart(cart cart) {
		this.cart = cart;
	}
	@Override
public Boolean verifyUser() {
	return true;
	}
	protected String getuserId() {
		return productId;
	}
	public void setProductuserId(String productId) {
		this.productId = productId;}
		protected String getProductId() {
			return productId;
		}
		public void setProductId(String userId) {
			this.userId = userId;
			
}
	
	}		 
