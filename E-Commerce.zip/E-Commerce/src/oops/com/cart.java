package oops.com;
  
public class cart {
private	String CartId;
protected String getCartId() {
		return CartId;
	}

	protected void setCartId(String cartId) {
		this.CartId = cartId;
	}

private Product[] listofProducts;

protected Product[] getListofProducts() {
	return listofProducts;
}

protected void setListofProducts(Product[] listofProducts) {
	this.listofProducts = listofProducts;
}
public Boolean checkout() {
	return true;
}

}
