package oops.com;


public class Order {
     private String orderId;
     private Customer user;

protected String getOrderId() {
		return orderId;
	}
protected void setOrderId(String orderId) {
	this.orderId = orderId;
}	
protected Customer getUser() {
	return user;
}
protected void setUser(Customer user) {
	this.user = user;
}

	}

