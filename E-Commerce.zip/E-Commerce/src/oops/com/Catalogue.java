package oops.com;


public class Catalogue {

private Product [] listofAllProducts;

protected Product[] getListofAllProducts() {
	Product Product1 = new Product();
	Product1.setProductId("1");
	Product1.setProductName("Product 1");
	Product1.setCost("100") ;
    Product Product2 = new Product();
    Product2.setProductId("2");
 	Product1.setProductName("Product 2");
 	Product1.setCost("200") ;
 	listofAllProducts= new Product[2]; 
 	listofAllProducts[0]=Product1;
 	listofAllProducts[1]=Product2;
	return listofAllProducts;
}

protected void setListofAllProducts(Product[] listofAllProducts) {
	this.listofAllProducts = listofAllProducts;
}

}