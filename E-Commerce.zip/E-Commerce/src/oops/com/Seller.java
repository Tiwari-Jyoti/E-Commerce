package oops.com;


public class Seller extends User {
	private Product[] listofProducts;	 
	@Override
	public Boolean verifyUser() {
    	return true ;
	}
	protected Product[] getListofProducts() {
		return listofProducts;
	}
	protected void setListofProducts(Product[] listofProducts) {
		this.listofProducts = listofProducts;
	}
	

}
