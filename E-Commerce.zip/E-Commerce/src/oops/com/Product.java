package oops.com;

class Product {
private String productId;
private String Cost;
private String productName;
private Seller seller;

protected Seller getSeller() {
	return seller;
}
protected void setSeller(Seller seller) {
	this.seller = seller;
}
protected String getProductId() {
	return productId;
}
public void setProductId(String productId) {
	this.productId = productId;
}
protected String getCost() {
	return Cost;
}
protected void setCost(String cost) {
	Cost = cost;
}
protected String getProductName() {
	return productName;
	}
public void setProductName(String productName) {
	this.productName = productName;
		
}

}

